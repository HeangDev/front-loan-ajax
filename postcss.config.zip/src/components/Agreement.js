import React from "react";
const Agreement = () => {
 

  return (
    <>
      
        <div className="pop_wrap msg_wrap flexCenter">
          <div className="pop_inn mgbox_inn">
            <div className="pop_content">
              <div className="pop_msg">
                <p>แน่ใจไหมว่าต้องการออกจากระบบบัญชีปัจจุบัน</p>
              </div>
            </div>
            <div className="pop_footer">
              <button  className="btn_g100" > ยกเลิก </button>
            </div>
          </div>
        </div>
    
    </>
  );
};

export default Agreement;
