export const userloan = [
    {
        id: 1,
        date: '2022-11-16',
        tel: '083****02',
        amount: '159100'
    },
    {
        id: 2,
        date: '2022-11-16',
        tel: '064****93',
        amount: '58600'
    },
    {
        id: 3,
        date: '2022-11-16',
        tel: '088****45',
        amount: '198200'
    },
    {
        id: 4,
        date: '2022-11-16',
        tel: '093****74',
        amount: '183600'
    },
    {
        id: 5,
        date: '2022-11-16',
        tel: '094****78',
        amount: '172400'
    }
]