#### How to install
<ol>
    <li><code>npm install</code></li>
    <li><code>npm start</code></li>
</ol>